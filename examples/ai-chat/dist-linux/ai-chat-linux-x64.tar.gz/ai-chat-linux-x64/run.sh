#!/usr/bin/env bash
# 由 scripts/pack-linux.sh 生成：切到包根 → 库路径指向包内 lib/ → 拉起 main。
# 参数原样透传给 main；stderr 直接进终端（要用日志文件就设 CJ_TAURI_LOG=1）。
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"
export LD_LIBRARY_PATH="$HERE/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
# 内置 cjh：应用（ai-chat）会按这个变量 spawn 它；cjh 自己的配置与会话仍写在 ~/.cjh
export CJ_AICHAT_CJH="$HERE/bin/cjh"
exec "$HERE/main" "$@"
